#!/usr/bin/env bash
set -euo pipefail
mkdir -p data/pbmc3k
curl -L --fail --output /tmp/pbmc3k_filtered.tar.gz https://cf.10xgenomics.com/samples/cell/pbmc3k/pbmc3k_filtered_gene_bc_matrices.tar.gz
tar -xzf /tmp/pbmc3k_filtered.tar.gz -C data/pbmc3k
mv data/pbmc3k/filtered_gene_bc_matrices/hg19 data/pbmc3k/filtered_feature_bc_matrix
ls -lh data/pbmc3k/filtered_feature_bc_matrix
