# Python script: scripts/01_scanpy_qc_clustering.py
# Input: Cell Ranger filtered 10x MEX directory (gene-expression features)
# Output: results/pbmc_scanpy.h5ad and figures in results/figures/

import os
import scanpy as sc

os.makedirs("results/figures", exist_ok=True)
sc.settings.figdir = "results/figures"

# Read 10x MEX files; v3+ compressed filenames are expected by default.
adata = sc.read_10x_mtx(
    "data/pbmc3k/filtered_feature_bc_matrix/",
    var_names="gene_symbols",
    cache=True,
    gex_only=True,
)
adata.var_names_make_unique()

# Identify mitochondrial genes using the naming convention in this reference.
# Change the prefix/case rule if your feature annotation uses another convention.
adata.var["mt"] = adata.var_names.str.upper().str.startswith("MT-")
sc.pp.calculate_qc_metrics(adata, qc_vars=["mt"], percent_top=None, inplace=True)
sc.pl.violin(
    adata,
    ["total_counts", "n_genes_by_counts", "pct_counts_mt"],
    jitter=0.4,
    multi_panel=True,
    save="_qc_violin.png",
)

# Example filters only: inspect distributions and choose criteria for this sample.
print(f"Cells before QC filters: {adata.n_obs}")
adata = adata[adata.obs["n_genes_by_counts"] > 200].copy()
print(f"After lower gene-count filter: {adata.n_obs}")
adata = adata[adata.obs["n_genes_by_counts"] < 2500].copy()
print(f"After upper gene-count filter: {adata.n_obs}")
adata = adata[adata.obs["pct_counts_mt"] < 5].copy()
print(f"After mitochondrial filter: {adata.n_obs}")

# Preserve count values because seurat_v3 HVG selection expects counts.
adata.layers["counts"] = adata.X.copy()
sc.pp.normalize_total(adata, target_sum=1e4)
sc.pp.log1p(adata)
adata.raw = adata.copy()  # log-normalized expression before restricting to HVGs
sc.pp.highly_variable_genes(
    adata, n_top_genes=2000, flavor="seurat_v3", layer="counts"
)
adata = adata[:, adata.var.highly_variable].copy()
sc.pp.scale(adata, max_value=10)

# Inspect the variance plot, then use the same selected PC range below.
sc.tl.pca(adata, svd_solver="arpack")
sc.pl.pca_variance_ratio(adata, log=True, save="_pca_elbow.png")
sc.pp.neighbors(adata, n_neighbors=10, n_pcs=10)  # adjust n_pcs after inspection
sc.tl.leiden(adata, resolution=0.5)
sc.tl.umap(adata)
sc.pl.umap(adata, color=["leiden"], save="_umap_clusters.png")
adata.write("results/pbmc_scanpy.h5ad")
