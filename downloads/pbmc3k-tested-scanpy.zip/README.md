# Reproduce the public PBMC 3k worked example

The published OmicsHub Python script completed twice, unchanged, on public 10x healthy-donor PBMC 3k data. This download contains the exact script, the lesson's staging commands, full pinned package versions, input checksums, recorded output summaries and logs. No thesis data, private results or raw input files are included.

## Run it

Tested on Linux with Python 3.12.3. Begin in this extracted folder. The matrix download is about 7.3 MB; the saved AnnData output is about 71 MB. The script scales a sparse matrix into a dense one, so memory requirements grow substantially with larger datasets.

```bash
python3.12 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements-tested.txt
bash scripts/stage_pbmc.sh
export MPLBACKEND=Agg
export OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 MKL_NUM_THREADS=2 NUMBA_NUM_THREADS=2
python scripts/01_scanpy_qc_clustering.py
```

Use a fresh workspace. The verbatim staging commands use `/tmp/pbmc3k_filtered.tar.gz` and move an extracted directory; rerunning them over an existing `data/` directory is not an idempotent setup procedure. Do not run the input-staging script twice in the same workspace without inspecting/removing that public-data directory first.

`MPLBACKEND=Agg` saves plots without opening windows. Scanpy still emits a noninteractive-display warning, but the PNG files are written. Interactive users may omit this environment setting. A warning about scaling a sparse matrix is expected; the current Leiden-default warning is recorded, not suppressed.

## Checkpoints measured in this environment

| Step | Cells retained |
|---|---:|
| Input matrix | 2,700 |
| More than 200 detected genes | 2,700 |
| Fewer than 2,500 detected genes | 2,695 |
| Mitochondrial-count percentage below 5 | 2,638 |

The example retained 97.70% of input cells and removed 62. These are run checkpoints for this archive and this code, not universal QC targets. The 2,500-gene and 5% cutoffs were executed as written, not validated as biologically optimal thresholds.

The input has 32,738 genes; the final analysis matrix uses 2,000 highly variable genes. The saved object contains nine Leiden groups (labels 0–8), 50 computed PCA components, a neighbor graph built using the first 10 PCs, and a two-dimensional UMAP. Groups were not annotated as cell types, and no doublet calling or marker validation was performed.

## Files the script creates

- `results/figures/violin_qc_violin.png`: QC distributions before the example cell filters.
- `results/figures/pca_variance_ratio_pca_elbow.png`: PCA variance-ratio diagnostic.
- `results/figures/umap_umap_clusters.png`: nine numeric Leiden labels, not cell-type identities.
- `results/pbmc_scanpy.h5ad`: AnnData object; `.X` is scaled HVG expression, `.layers["counts"]` stores untransformed counts for those HVGs, and `.raw` stores log-normalized expression for all 32,738 genes. The `.raw` name does not mean raw count values here.

## What repeating it established

Two separate executions in the same pinned environment used the same cells and HVGs and produced identical QC metrics, Leiden labels and UMAP coordinates (maximum absolute UMAP difference 0). PCA coordinates agreed at tolerance 1e-6. This does not establish cross-platform or cross-version equality. The QC jitter plot's pixels are not claimed identical. Scanpy's tested PCA, neighbor, Leiden and UMAP functions use their documented default `random_state=0`; the script has not been rewritten to change its algorithms or defaults.

The full dependency lock is in `requirements-tested.txt`: Scanpy 1.11.5, scikit-misc 0.5.2, igraph 0.11.9 and leidenalg 0.10.2 are among the recorded versions. Install the complete lock to reproduce the tested environment, rather than just those four packages.

## Limits and data source

Only the Scanpy/Python path was executed. The Seurat/R path was not executed. This is matrix-to-QC-to-clustering, not a raw-FASTQ processing workflow, tumor analysis, clinical validation or evidence that every OmicsHub tutorial has run end to end.

Data: [10x PBMC 3k archive used by the lesson](https://cf.10xgenomics.com/samples/cell/pbmc3k/pbmc3k_filtered_gene_bc_matrices.tar.gz), using the hg19 legacy gene-barcode matrix. [Scanpy's public dataset description](https://scanpy.readthedocs.io/en/stable/api/scanpy.datasets.pbmc3k.html) confirms the healthy-donor dataset and input dimensions. Archive SHA256: `847d6ebd9a1ec9a768f2be7e40ca42cbfe75ebeb6d76a4c24167041699dc28b5`.
